This directory contains some sample data conforming to the LOST export/import format.

files:
assets.csv - asset data
facilities.csv - facilities data
transfers.csv - transfer data
users.csv - user date